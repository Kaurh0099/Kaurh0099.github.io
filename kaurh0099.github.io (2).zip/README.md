# Idea:
•	Add the name of the restaurant on the main page
•	Add the main common bars on the main page 
•	Search bar for “Search items
•	Write a slogan 
•	Add an image of food
•	In a table, give, menu list

# Changes 
•	Use colors for headings 
•	Provie contact information at the end of website 
•	Give location 

# Feedback from friends
The images size should be increase in the website to make it clear and add a line between Main page and menu section to make it more clear.And also use background colour   

# Attributions & Citations 
•	"A table topped with a lot of plates" by Davey Gravy under Unsplash License. 
https://unsplash.com/photos/a-table-topped-with-lots-of-plates-of-food-hatqfX3b9Vo

•	"Cooked food on black bowl" by Eiliv Aceron under Unsplash License. 
https://unsplash.com/photos/cooked-food-on-black-bowl-ZuIDLSz3XLg

•	https://unsplash.com/photos/cooked-food-on-black-bowl-ZuIDLSz3XLg
    "Raspberry cake" by Anna Tukhfatullina under Unsplash License. 
 https://unsplash.com/photos/raspberry-cake-Mzy-OjtCI70


# Kaurh0099.github.io